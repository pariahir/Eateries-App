//
//  Eaterie.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import Foundation

/// Model of the app(declare all variable with class, implement init put enum and decoder-encoder for JSON)
class Eaterie: ObservableObject, Decodable, Encodable, Identifiable {
    
    /// made all wanted varible name and pass their type also decalre with Published becuse i in my Restaurant Class i passsed it with the ObservableObject for the Best Eateries application
    var id = UUID()
    @Published var image: String
    @Published var title: String
    @Published var location: String
    @Published var latitude: String
    @Published var longitude: String
    @Published var notes: String
    @Published var review: [Review]
    
    /// made one initi method to pass my all varibale with their type which is string.
    /// - Parameters:
    ///   - image: made the image varibale and it's type is string for downloading image.
    ///   - title: made the title variable for displace the name of the restaurant and it's type is string.
    ///   - location: made the location variable for displaded location of the restaurant and it's type is string.
    ///   - notes: made the notes variable for displaded notes of the restaurant and it's type is string.
    ///   - review: made the review variable for displaded review of the restaurant and it's type is string.
    ///   - author: made the author variable for displaded reviewer's author of the restaurant and it's type is string.
    ///   - content: made the content variable for displaded reviewer's content of the restaurant and it's type is string.
    init(image: String, title: String, location: String, latitude: String, longitude:String, notes: String, review: [Review]) {
        self.image = image
        self.title = title
        self.location = location
        self.latitude = latitude
        self.longitude = longitude
        self.notes = notes
        self.review = review
    }
    
    /// eum define the type of values which published as varibales. enum is used when we know all possible values at build time. and it's represted the enum data type.
    enum CodingKeys: String, CodingKey, RawRepresentable {
        case image
        case title
        case location
        case latitude
        case longitude
        case notes
        case review
    }
    
    /// this is for decode a JSON string and pass the decalred varible's name with their type.
    /// - Parameter decoder: it is custom data formates and it is get data from out of the app, and main thing is that it is a boolean varibale so, is it's true then objectes returend with converted associative array.
    /// - Throws: it will return the decodable varibels values with their types.
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        image = try container.decode(String.self, forKey: .image)
        title = try container.decode(String.self, forKey: .title)
        location = try container.decode(String.self, forKey: .location)
        latitude = try container.decode(String.self, forKey: .latitude)
        longitude = try container.decode(String.self, forKey: .longitude)
        notes = try container.decode(String.self, forKey: .notes)
        review = try container.decode([Review].self, forKey: .review)
    }
    
    /// encode means it can encode the varibales value into a native formate fot the external representation like JSON.
    /// - Parameter encoder: it is convert the saved data and it will sent that data to over the network which is in suitable format.
    /// - Throws: here is Eateries app's object and assign value types of the varibles.
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(image, forKey: .image)
        try container.encode(title, forKey: .title)
        try container.encode(location, forKey: .location)
        try container.encode(latitude, forKey: .latitude)
        try container.encode(longitude, forKey: .longitude)
        try container.encode(notes, forKey: .notes)
        try container.encode(review, forKey: .review)
    }
}
