//
//  EateriesApp.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import SwiftUI
@main
struct EateriesApp: App {
    
    /// This is the Mailn App here save the data in JSONSerialisation.
    @StateObject var viewModel: LocationViewModel = LocationViewModel(name: "Location", latitude: -27.35, longitude: 153.026)
    @State var model: [Eaterie] = EateriesApp.model
       static var model: [Eaterie] = {
           guard let data  = try? Data(contentsOf: EateriesApp.fileURL),
                 let model = try? JSONDecoder().decode([Eaterie].self, from: data) else {
               return MasterData
           }
           return model
       }()
       static var modelBinding: Binding<[Eaterie]>?

       var body: some Scene {
        EateriesApp.modelBinding = $model
           return WindowGroup {
            ContentView(eaterie: $model, titleEdit: "The Best Eateries", location: viewModel, latitude: viewModel, longitude: viewModel)
           }
       }

       static var fileURL: URL {
           let fileName = "Eaterie.json"
           let fm = FileManager.default
           guard let documentDir = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return URL(fileURLWithPath: "/") }
           let fileURL = documentDir.appendingPathComponent(fileName)
           return fileURL
       }

       static func save() {
           do {
               let data = try JSONEncoder().encode(modelBinding?.wrappedValue ?? model)
               try data.write(to: fileURL, options: .atomic)
               guard let dataString = String(data: data, encoding: .utf8) else { return }
               print(dataString)
           } catch {
               print("Could not write file: \(error)")
           }
       }
   }
