//
//  LazyTextField.swift
//  Eateries
//
//  Created by pc ahir on 20/5/21.
//
import SwiftUI

/// This SwiftUi file can update the values, When i am going to change location name it's will be updated in TextField location's name, latitude and longitude.
struct LazyTextField: View {
    var prompt: String
    @State var string = String ()
    var commit: () -> Void = {}
    let originalBinding: Binding<String>
    
    init(_ prompt: String, text: Binding<String>, onCommit: @escaping () -> Void = {}) {
        self.prompt = prompt
        originalBinding = text
        string = text.wrappedValue
        commit = onCommit
    }
    func updateBinding()  {
        print("Updating Binding to <\(string)>")
        originalBinding.wrappedValue = string
    }
    
    var body: some View {
        TextField(prompt, text: $string,onEditingChanged: {
            if $0 == false { updateBinding() }
        }, onCommit: commit)
        .onDisappear(perform: updateBinding)
    }
}
