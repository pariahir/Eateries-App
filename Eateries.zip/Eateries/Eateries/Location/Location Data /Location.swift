//
//  Location.swift
//  Eateries
//
//  Created by pc ahir on 20/5/21.
//
import Foundation

/// Structure of the Location's 3 varibales called location name, their latitude and longitude.
struct Location {
    var name: String
    var latitude: Double
    var longitude: Double
}
