//
//  LocationViewModel.swift
//  Eateries
//
//  Created by pc ahir on 20/5/21.
//
import Foundation

/// This is the Swift File. Here i made class LocationViewModel and pass their varibales's. as well made init method for declare varibales type and the i want get and set (for when i am going to click on location i want their location's new latitude and longitude).
class LocationViewModel: NSObject, ObservableObject {
    @Published var model: Location
    @Published var latitudeSpan = 0.01
    @Published var longitudeSpan = 0.01
    
    init(name: String, latitude: Double, longitude: Double) {
        model = Location(name: name, latitude: latitude, longitude: longitude)
    }
    
    var latitudeString: String {
        get { "\(model.latitude)"}
        set {
            guard let doubleValue = Double(newValue) else { return }
            model.latitude = doubleValue
        }
    }
    var longitudeString: String {
        get { "\(model.longitude)"}
        set {
            guard let doubleValue = Double(newValue) else { return }
            model.longitude = doubleValue
        }
    }
}
