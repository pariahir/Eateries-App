//
//  LocationArray.swift
//  Eateries
//
//  Created by pc ahir on 24/5/21.
//
import Foundation

/// in this swift file i made the Location Array.
class LocationArray: ObservableObject {
    @Published var location: [Eaterie]
    
    init(location: [Eaterie]) {
        self.location = location
    }
}
