//
//  LocationTest.swift
//  Eateries
//
//  Created by Purvaben Pradipkumar Chhuchhar on 21/5/21.
//
import SwiftUI

/// This is the SwiftUi file for the UI Designing of Location on DetailView. and it will save on EateriesApp help with JSONSerialisation.
struct LocationView: View {
    @ObservedObject var location: LocationViewModel
    @ObservedObject var eaterie: Eaterie
    
    var body: some View {
        VStack {
            // Name of the location (like, World's city, country etc)
            TextField("Enter Location Name", text: $eaterie.location, onCommit: {
                location.lookupPosition(eaterie: eaterie)
                EateriesApp.save()
            })
            .font(Font.system(.body, design: .serif))
            .foregroundColor(Color.black)
            
            // Display Latitude of the Entered Location. Or Change with manual in TextField.
            TextField("Enter latitude", text: $eaterie.latitude, onCommit: {
                        location.lookupName(eaterie: eaterie)
                EateriesApp.save()
            })
            .font(Font.system(.body, design: .serif))
            .foregroundColor(Color.black)
            
            //Display Longitude of the Entered Location. Or Change with manual in TextField.
            TextField("Enter longitude", text: $eaterie.longitude, onCommit: {
                        location.lookupName(eaterie: eaterie)
                EateriesApp.save()
            })
            .font(Font.system(.body, design: .serif))
            .foregroundColor(Color.black)
            
        }.padding().onAppear(){
            location.lookupPosition(eaterie: eaterie)
        }
        MapView(viewModel: location)
    }
}
//struct LocationTest_Previews: PreviewProvider {
//    static var previews: some View {
//        LocationTest()
//    }
//}
