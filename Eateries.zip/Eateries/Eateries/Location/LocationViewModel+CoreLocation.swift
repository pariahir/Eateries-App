//
//  LocationViewModel+CoreLocation.swift
//  Eateries
//
//  Created by pc ahir on 20/5/21.
//
import CoreLocation

/// This file is for GoeCoding pass thie latitude and longitude with get and set as well here made 2 functions 1 is lookupName is give a location's name means subLocality, locality, area etc, 2 is lookupPosition it's give specific location's latitude and longitude's coordinates (For Example, when i am going to change the location name called Paris it will change the coordinated and give me a Paris Coordinates.
private var isGeoCoding = false

extension LocationViewModel {
    var location: CLLocation {
        get { CLLocation(latitude: model.latitude, longitude: model.longitude)}
        set {
            model.latitude = newValue.coordinate.latitude
            model.longitude = newValue.coordinate.longitude
        }
    }
    var coordinates: CLLocationCoordinate2D {
        get { CLLocationCoordinate2D(latitude: model.latitude, longitude: model.longitude)}
        set {
            model.latitude = newValue.latitude
            model.longitude = newValue.longitude
        }
    }
    func lookupName(eaterie: Eaterie) {
        guard !isGeoCoding else { return }
        isGeoCoding = true
        let geoCoder = CLGeocoder()
        let location: CLLocation = CLLocation.init(latitude: Double(eaterie.latitude) ?? 0.0, longitude: Double(eaterie.longitude) ?? 0.0)
        geoCoder.reverseGeocodeLocation(location) {
            isGeoCoding = false
            guard let placeMarks = $0, let placeMark = placeMarks.first else {
                if let error = $1 {
                    print("Error looking up location \(error.localizedDescription)")
                }else {
                    print("Error looking up location \(String(describing: $1))")
                }
                return
            }
            eaterie.location = placeMark.name ?? placeMark.locality ??
                placeMark.subLocality ?? placeMark.administrativeArea ??
                placeMark.country ?? "<unknown>"
        }
    }
    func lookupPosition(eaterie: Eaterie) {
        guard !isGeoCoding else { return }
        isGeoCoding = true
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(eaterie.location) {
            isGeoCoding = false
            guard let placeMarks = $0, let placeMark = placeMarks.first,
                let coordinates = placeMark.location?.coordinate else {
                if let error = $1 {
                    print("Error looking up location \(error.localizedDescription)")
                }else {
                    print("Error looking up location \(String(describing: $1))")
                }
                return
            }
            print(coordinates.latitude)
            eaterie.latitude = String(coordinates.latitude)
            eaterie.longitude = String(coordinates.longitude)
            self.model.latitude = coordinates.latitude
            self.model.longitude = coordinates.longitude
        }
    }
}
