//
//  LocationViewModel+MapKit.swift
//  Eateries
//
//  Created by pc ahir on 20/5/21.
//
import MapKit

/// In this File is for MAP it will give the coordinates when we change the location name. it's give new latitude and longitude's value with their Delta and Span and then it's update with count and give the right coordinated of the specific location.
private var updateCount = 0

extension LocationViewModel: MKMapViewDelegate  {
    var coordinateSpan: MKCoordinateSpan {
        get { MKCoordinateSpan(latitudeDelta: latitudeSpan, longitudeDelta: longitudeSpan)}
        set {
            latitudeSpan = newValue.latitudeDelta
            longitudeSpan = newValue.longitudeDelta
        }
    }
    
    var region: MKCoordinateRegion {
        get { MKCoordinateRegion(center: coordinates, span: coordinateSpan)}
        set { coordinateSpan = newValue.span}
    }
    
    @objc func mapViewDidChangeVisibleRegion(_ mapView: MKMapView) {
        let centre = mapView.centerCoordinate
        updateCount += 1
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(250)) {
            updateCount -= 1
            guard updateCount == 0 else { return }
            self.coordinates = centre
        }
    }
}
