//
//  MapView.swift
//  Eateries
//
//  Created by pc ahir on 20/5/21.
//
import MapKit
import UIKit
import SwiftUI

/// For Map when change the location name it's updated on map with their coordinates as well when we updated the corrdinated on map it is going to change latitude and longitude.
struct MapView: UIViewRepresentable {
    @ObservedObject var viewModel: LocationViewModel
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        mapView.delegate = viewModel
        return mapView
    }
    func updateUIView(_ uiView: MKMapView, context: Context) {
        uiView.setRegion(viewModel.region, animated: true)
    }
}
