//
//  EaterieArray.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import Foundation

/// Made Array of the Restaurant.
class EaterieArray: ObservableObject {
    @Published var eaterie: [Eaterie]
    
    /// Made init Method for the Restarant to pass my all varibles whihch is in the Restaurant File.
    /// - Parameter restaurant: i made one varibale called the restaurant to pass my Restaurant Array.
    init(eaterie: [Eaterie]) {
        self.eaterie = eaterie
    }
}
