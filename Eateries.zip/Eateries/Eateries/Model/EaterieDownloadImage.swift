//
//  EaterieDownloadImage.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import Foundation
import SwiftUI
import UIKit

/// Made Structure for Restaurant Downloding Image and then made varibale called model and pass it into the string.
struct EaterieDownloadImage : View{
    var model: String
    
    //var restaurant: Restaurant
    /// made init method to pass my model type is string.
    /// - Parameter model: declare self model into string.
    init(model:String) {
        self.model = model
    }
    var image: Image{
        let emptyImage = Image("nonexistent")
        guard let url = URL(string: model) else {
            return emptyImage
        }
        guard let data = try? Data(contentsOf: url) else {
            return emptyImage
        }
        guard let uiImage = UIImage(data: data) else {
            return emptyImage
        }
        return Image(uiImage: uiImage)
    }
    
    var body: some View{
        VStack(alignment: .center) {
            //Image
            image
                .resizable()
                .frame(width: 350, height: 300, alignment: .center)
                .shadow(radius: 4.0)
                .clipShape(RoundedRectangle(cornerRadius: 20))
        }
    }
}
