//
//  EaterieTitle.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import SwiftUI

/// Master View Display Data (image, title, location) and UI Design.
struct EaterieTitle: View {
    @ObservedObject var eaterie: Eaterie
    var body: some View {
        //Thumbnail of Downloding Image with imageURL
        EaterieDownloadImage(model: eaterie.image)
            .aspectRatio(contentMode: .fit)
            .frame(width: 100, height: 100, alignment: .center)
            .cornerRadius(60)
            .shadow(radius: 6)
            VStack(alignment: .leading){
                //Title
                Text(eaterie.title)
                    .font(.headline)
                //Location
                Text(eaterie.location)
                    .font(.subheadline)
                    .font(.caption).italic()
                }
            }
        }
//struct RestaurantTitle_Previews: PreviewProvider {
//    static var previews: some View {
//        RestaurantTitle()
//    }
//}
