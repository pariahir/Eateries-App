//
//  MasterData.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import Foundation

/// Make one separate File for the static data for Master Detail View File of the Eateries App.
let MasterData: [Eaterie] = [
    Eaterie(image: "Liebe", title: "Liebe Restaurant", location: "46 rue du Faubourg Montmartre 75009 Paris", latitude: "1.01", longitude: "1.01", notes: "Nice location and yummy food", review: [Review(author: "Pari", content: "Nice Food")]),
    
    Eaterie(image: "Park-Grill", title: "Park Grill Restaurant", location: "156 Central Rd, Worcester Park KT4 8HH, United Kingdom", latitude: "1.01", longitude: "1.01", notes: """
            location is amazing!!!
            Tastiest Food.
            I like this restaurant so much.
            """, review: [Review(author: "PC Ahir", content: "Amazing")]),
    
    Eaterie(image: "Portland", title: "Portland Restaurant", location: "113 Great Portland St, London W1W 6QQ, United Kingdom", latitude: "1.01", longitude: "1.01", notes: """
        “Excellent environment, friendly service, great menu choices and really decent food and at affordable prices.
         Will be back.
         What a lovely restaurant, good food and service and atmosphere, definitely hope to go back.
         I really enjoyed my vaction with this beautiful Restaurant!!!
""", review: [Review(author: "Vishu Chhuchhar", content: "Awesome")]),
    
    Eaterie(image: "Daark", title: "Daark Espresso", location: "2/41 Musgrave Ave, Labrador QLD 4215", latitude: "1.01", longitude: "1.01", notes: "nice food", review: [Review(author: "Nilu Karangiya", content: "Nice food!!")]),
    
    Eaterie(image: "Main", title: "Main Restaurant", location: "223 Palmer St, East Sydney NSW 2010", latitude: "1.01", longitude: "1.01", notes: "good", review: [Review(author: "Dhara Karangiya", content: "Location nice!!")])
]
