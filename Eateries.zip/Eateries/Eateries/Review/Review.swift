//
//  Review.swift
//  Eateries
//
//  Created by pc ahir on 26/5/21.
//
import Foundation

/// In this Swift File i made class called Review and then declare Review's 2 Varibales called author and content. this class implement with the encoder and decoder so that i can save my review's with JSONSerialisation.
class Review: ObservableObject, Decodable, Encodable, Identifiable {
        @Published var author: String
        @Published var content: String
        
        init(author: String, content: String) {
            self.author = author
            self.content = content
        }
        enum CodingKeys: String, CodingKey, RawRepresentable {
            case author
            case content
        }

        required init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            author = try container.decode(String.self, forKey: .author)
            content = try container.decode(String.self, forKey: .content)
        }

        func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)
            try container.encode(author, forKey: .author)
            try container.encode(content, forKey: .content)
        }
    }
