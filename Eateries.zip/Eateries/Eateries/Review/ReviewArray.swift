//
//  ReviewArray.swift
//  Eateries
//
//  Created by pc ahir on 23/5/21.
//
import SwiftUI

/// I made ReviewArray here so, that i can pass the Author and Content.
struct ReviewArray: View {
    @ObservedObject var eaterie: Eaterie
    @Environment(\.editMode) var editMode
    
    var body: some View {
        NavigationView{
            ReviewViewModel(review: $eaterie.review)
                .navigationBarItems(leading: EditButton(), trailing: Button("+", action: {
                    eaterie.review.append(Review(author: "Author", content: "Content"))
                }))
        }
    }
}
