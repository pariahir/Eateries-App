//
//  ReviewTitle.swift
//  Eateries
//
//  Created by pc ahir on 27/5/21.
//

import SwiftUI

/// Here i made the one SwiftUI file for when i click on Review it's give me UI design of the Reviews 2 varibale's called author and content. and this Screen is editable.
struct ReviewTitle: View {
    @ObservedObject var review: Review
    @Environment(\.editMode) var editMode
    var body: some View {
        ScrollView{
                VStack(alignment: .center){
                    Group{
                        //Review's Author
                        Text("Author")
                            .font(.title3)
                            .foregroundColor(Color.gray)
                        TextField("Author", text: $review.author, onCommit: {
                            EateriesApp.save()
                        })
                        .font(.system(.title3, design: .serif))
                        .foregroundColor(Color.black)
                        .multilineTextAlignment(.center)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        
                        //Review's Content
                        Text("Content")
                            .font(.title3)
                            .foregroundColor(Color.gray)
                        TextField("Content", text: $review.content, onCommit: {
                            EateriesApp.save()
                        })
                        .font(.system(.title3, design: .serif))
                        .foregroundColor(Color.black)
                        .multilineTextAlignment(.center)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    }
            }
        }
    }
}
//struct ReviewTitle_Previews: PreviewProvider {
//    static var previews: some View {
//        ReviewTitle()
//    }
//}
