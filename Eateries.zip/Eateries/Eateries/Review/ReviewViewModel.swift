//
//  ReviewViewModel.swift
//  Eateries
//
//  Created by pc ahir on 27/5/21.
//
import SwiftUI

/// This SwiftUI file for the Review's here i pass the List and declare ForEach loop for Add Review.
struct ReviewViewModel: View {
    @Binding var review: [Review]
    @Environment(\.editMode) var editMode
    
    var body: some View {
        VStack(alignment: .center) {
            List{
                ForEach(review) {review in
                    ReviewTitle(review: review)
                }.onMove {
                    review.move(fromOffsets: $0, toOffset: $1)
                    EateriesApp.save()
            }.onDelete {
                review.remove(atOffsets: $0)
                EateriesApp.save()
            }
            }
        }
    }
}
//struct ReviewViewModel_Previews: PreviewProvider {
//    static var previews: some View {
//        ReviewViewModel()
//    }
//}
