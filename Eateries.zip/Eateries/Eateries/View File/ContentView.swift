//
//  ContentView.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import SwiftUI

/// The main detail view of this Eateries Application (Title bar in title of the Restaurant- Add button(add new value), Edit button(Edit new and Existing Item))
struct ContentView: View {
    @Binding var eaterie: [Eaterie]
    @State var titleEdit: String
    @ObservedObject var location: LocationViewModel
    @ObservedObject var latitude: LocationViewModel
    @ObservedObject var longitude: LocationViewModel
    @Environment(\.editMode) var editMode

    var body: some View {
        NavigationView {
            MasterView(eaterie: $eaterie, titleEdit: titleEdit, location: location, latitude: latitude, longitude: longitude)
                .navigationTitle("The Best Eateries")
                .navigationBarItems(leading: EditButton(), trailing: Button("+", action: { eaterie.append(Eaterie(image: "Image", title: "Title", location: "Location", latitude: "1.01", longitude: "1.01", notes: "notes", review: [Review(author: "Author", content: "Content")]))}))
        }
    }
}
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView(eaterie: Binding(get: {
//            EateriesApp.model
//        }, set: { newValue in
//            EateriesApp.model = newValue
//        }))
//    }
//}
