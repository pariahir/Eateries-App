//
//  DetailView.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import SwiftUI

/// Detail View of the Eateries App (static data and new addded data's detail, UI Designing for Detail View Data) all the varibales decalred in the Eateries Model here it's edit and updated.
struct DetailView: View {
    @ObservedObject var eaterie: Eaterie
    @ObservedObject var location: LocationViewModel
    @ObservedObject var latitude: LocationViewModel
    @ObservedObject var longitude: LocationViewModel
    @Environment(\.editMode) var editMode
    
    /// MAde UI Designing and Editabled TextField for the All Eateries Model variables. here we can manual edit imageurl from google, title, location, notes and reviews.
    var body: some View {
        ScrollView{
            NavigationView{
                
            }.navigationBarItems(trailing: EditButton())
            Group {
                VStack(alignment: .center){
                    // Downloding Image with ImageURL
                    EaterieDownloadImage(model: eaterie.image)
                    TextField("Image", text: $eaterie.image, onCommit: {
                        EateriesApp.save()
                    })
                    .font(.system(.title, design: .serif))
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                }
                
                VStack(alignment: .leading){
                    Group{
                        //Title
                        Text("Title")
                            .font(.system(.title, design: .serif))
                            .foregroundColor(Color.gray)
                            .frame(width: 400, height: 50, alignment: .center)
                        TextField("Title", text: $eaterie.title, onCommit: {
                            EateriesApp.save()
                        })
                        .font(.system(.title, design: .serif))
                        .foregroundColor(Color.black)
                        .multilineTextAlignment(.center)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        
                        //Location
                        VStack{
                            NavigationLink(destination: LocationView(location: location, eaterie: eaterie), label: {
                                Text(eaterie.location)
                                    .font(.system(.title, design: .serif))
                                    .foregroundColor(.blue)
                                    .frame(width: 400, height: 50, alignment: .center)
                            })
                            }
                        }
                    
                        //Notes
                        Text("Notes")
                            .font(.system(.title, design: .serif))
                            .frame(width: 400, height: 50, alignment: .center)
                            .foregroundColor(.gray)
                        TextEditor(text: $eaterie.notes)
                            .onDisappear(){
                                EateriesApp.save()
                            }
                            .font(.system(.body, design: .serif))
                            .frame(width: 400, height: 50, alignment: .center)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.center)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                    
                    //Review
                    VStack{
                        NavigationLink(destination: ReviewArray(eaterie: eaterie), label: {
                            Text("Review")
                                .font(.system(.title, design: .serif))
                                .foregroundColor(Color.gray)
                                .frame(width: 400, height: 50, alignment: .center)
                        })
                    }
                }
            }
        }
    }
}
