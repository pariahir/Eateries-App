//
//  MasterView.swift
//  Eateries
//
//  Created by pc ahir on 19/5/21.
//
import SwiftUI
import Combine
import Foundation

/// This SwiftUi File is the Master View of The Eaterie App. Here, we can edit new or Existind data, Move new added or edited existing data, delete new addede or existing data. made one ForEach loop for Add new Data.
struct MasterView: View {
    @Binding var eaterie: [Eaterie]
    @State var titleEdit: String
    @ObservedObject var location: LocationViewModel
    @ObservedObject var latitude: LocationViewModel
    @ObservedObject var longitude: LocationViewModel
    @Environment(\.editMode) var editMode
    var body: some View {
        VStack{
            if editMode?.wrappedValue == .active {
                HStack{
                    Text("📝")
                        .font(.system(.title, design: .serif))
                        .foregroundColor(Color.gray)
                    TextField("Enter title", text: $titleEdit, onCommit: {
                        EateriesApp.save()
                    })
                    .font(.system(.title, design: .serif))
                    .foregroundColor(Color.black)
                }
            }
        }
        List{
            ForEach(eaterie) { eaterie in
                NavigationLink(
                    destination: DetailView(eaterie: eaterie, location: location, latitude: latitude, longitude: longitude)) {
                    EaterieTitle(eaterie: eaterie)
                }
            }.onMove {
                eaterie.move(fromOffsets: $0, toOffset: $1)
                EateriesApp.save()
                
            }.onDelete {
                eaterie.remove(atOffsets: $0)
                EateriesApp.save()
            }
        }.navigationTitle(editMode?.wrappedValue == .active ? "" : titleEdit)
    }
}
//struct MasterView_Previews: PreviewProvider {
//    static var previews: some View {
//        MasterView()
//    }
//}
