//
//  EateriesTests.swift
//  EateriesTests
//
//  Created by pc ahir on 19/5/21.
//

import XCTest
@testable import Eateries


/// Here i made the EateriesTests .

class EateriesTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    /// Here i made the EateriesTests in this test i was test all the variable's with their Dummy data. tests all varibales with XCTAssertEqual (It's work is my test data and decared data are Equal or not if equal my test is succssful if both data different my test is fail For Example, testImageToTest is "Liebe" and i pass eatrie = Eatrie(image: "Portland") here my test is going to fail.)
    /// - Throws: I was tested all the Varibales which was declare in Eaterie Model. so, i test 6 dummy data with all the variables whoch i was Declare in my Eaterie Model like, image, title, location, notes, [Review(Author and Content)].
    
    func testImage() throws {
        let testImageToTest = "Liebe"
        let eatrie = Eaterie(image: "Liebe", title: "Liebe Restaurant", location: "46 rue du Faubourg Montmartre 75009 Paris", latitude: "1.01", longitude: "1.01", notes: "Nice location and yummy food", review: [Review(author: "Pari", content: "Nice Food")])
        XCTAssertEqual(eatrie.image, testImageToTest)
    }
    
    func testTitle() throws {
        let testTitleToTest = "Park Grill Restaurant"
        let eatrie = Eaterie(image: "Park-Grill", title: "Park Grill Restaurant", location: "156 Central Rd, Worcester Park KT4 8HH, United Kingdom", latitude: "1.01", longitude: "1.01", notes: """
            location is amazing!!!
            Tastiest Food.
            I like this restaurant so much.
            """, review: [Review(author: "PC Ahir", content: "Amazing")])
        XCTAssertEqual(eatrie.title, testTitleToTest)
    }
    
    func testLocation() throws {
        let testLocationToTest = "223 Palmer St, East Sydney NSW 2010"
        let eatrie = Eaterie(image: "Main", title: "Main Restaurant", location: "223 Palmer St, East Sydney NSW 2010", latitude: "1.01", longitude: "1.01", notes: "good", review: [Review(author: "Dhara Karangiya", content: "Location nice!!")])
        XCTAssertEqual(eatrie.location, testLocationToTest)
    }
    
    func testLatitude() throws {
        let testLatitudeToTest = "1.01"
        let eatrie = Eaterie(image: "Daark", title: "Daark Espresso", location: "2/41 Musgrave Ave, Labrador QLD 4215", latitude: "1.01", longitude: "1.01", notes: "nice food", review: [Review(author: "Nilu Karangiya", content: "Nice food!!")])
        XCTAssertEqual(eatrie.latitude, testLatitudeToTest)
    }
    
    func testLongitude() throws {
        let testLongitudeToTest = "1.01"
        let eatrie = Eaterie(image: "Daark", title: "Daark Espresso", location: "2/41 Musgrave Ave, Labrador QLD 4215", latitude: "1.01", longitude: "1.01", notes: "nice food", review: [Review(author: "Nilu Karangiya", content: "Nice food!!")])
        XCTAssertEqual(eatrie.longitude, testLongitudeToTest)
    }
    
    func testNotes() throws {
        let testNotesToTest = """
        “Excellent environment, friendly service, great menu choices and really decent food and at affordable prices.
         Will be back.
         What a lovely restaurant, good food and service and atmosphere, definitely hope to go back.
         I really enjoyed my vaction with this beautiful Restaurant!!!
"""
        let eatrie = Eaterie(image: "Portland", title: "Portland Restaurant", location: "113 Great Portland St, London W1W 6QQ, United Kingdom", latitude: "1.01", longitude: "1.01", notes: """
        “Excellent environment, friendly service, great menu choices and really decent food and at affordable prices.
         Will be back.
         What a lovely restaurant, good food and service and atmosphere, definitely hope to go back.
         I really enjoyed my vaction with this beautiful Restaurant!!!
""", review: [Review(author: "Vishu Chhuchhar", content: "Awesome")])
        XCTAssertEqual(eatrie.notes, testNotesToTest)
    }
    
    func testAuthor() {
        let testAuthorToTest = "Dhara Karangiya"
        let review = Review(author: "Dhara Karangiya", content: "Location nice!!")
        XCTAssertEqual(review.author, testAuthorToTest)
    }
    
    func testContent() {
        let testContentToTest = "Location nice!!"
        let review = Review(author: "Dhara Karangiya", content: "Location nice!!")
        XCTAssertEqual(review.content, testContentToTest)
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
